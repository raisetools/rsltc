/* 
RSL Type Checker
Copyright (C) 2000 UNU/IIST

raise@iist.unu.edu
*/

#ifndef _RSL_convert_h
#define _RSL_convert_h

#include <string>
#include<stdlib.h>
#include "RSL_text.h"


char *convert(const char *ftype){
  if (!strcmp(ftype, "int")) return "INTEGER";
  else if (!strcmp(ftype, "double")) return "DOUBLE";
  else if (!strcmp(ftype, "long")) return "BIGINT";
  else if (!strcmp(ftype, "char") || !strcmp(ftype, "RSL_char")) return "CHAR(1)";
  else if (!strcmp(ftype, "string") || !strcmp(ftype, "RSL_string")) return RSL_DEF_LONG_STRING;
  else return RSL_DEF_LONG_STRING;
}

string cnvrtfstring(char *str, string ttype){
  if (ttype=="RSL_string") return (string)"\"" + str + "\"";
  if (ttype=="RSL_char")  return (string)"'" + str + "'"; 
  return (string)str;
}

string cnvrt2string(int i){
  char hold[100];
  sprintf(hold, "%d", i);
  string s=hold;
  return s;
}

string cnvrt2string(long i){
  char hold[100];
  sprintf(hold, "%d", i);
  string s=hold;
  return s;
}

string cnvrt2string(double i){
  char hold[100];
  sprintf(hold, "%f", i);
  string s=hold;
  return s;
}

string cnvrt2string(float i){
  char hold[100];
  sprintf(hold, "%f", i);
  string s=hold;
  return s;
}

string cnvrt2string(RSL_string i){
  string s("'");
  s+=i.RSL_f1; s+="'";
  return s;
}

string cnvrt2string(RSL_char i){
  string s("'");
  s+=i.RSL_f1; s+="'";
  return s;
}

string cnvrt2string(char *str){
  string s("'");
  s+=str; s+="'";
  return s;
}


template<typename T>
string cnvrt2string(T i){
  string s("'");
  return s + RSL_to_string(i)+"'";
}


template<typename T>
class FldData  {
private:
  string buf;
public:  
  FldData (const char *str) {buf=(string)str;}
  FldData () {}
   
  operator RSL_string() {return  buf ;}
  operator T() const {return string_to_RSL<T>(buf);}
  
  
};

// The first three versions of C2RSL are only templates
// because the fourth one needs to be, and C2RSL is always
// called with a template argument.

template<typename T>
RSL_char C2RSL(const char *t, const char c){
  return RSL_char(c);
}

template<typename T>
int C2RSL(const char *t, const int i){
  return i;
}

template<typename T>
double C2RSL(const char *t, const double d){
  return d;
}

template<typename T>
T C2RSL(const char *t, const char *s){
  string s1 = (!strcmp(t,"RSL_string")) ? (string)"\"" + s + "\"" : s;
  return string_to_RSL<T>(s1);
}



#endif // _RSL_convert_h








